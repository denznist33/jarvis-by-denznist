# JARVIS Paylasim Rehberi

Bu proje su an kisisel dosyalar ve API anahtarlari da iceriyor. Takipcilerinle guvenli sekilde paylasmak icin orijinal klasoru degil, temizlenmis paketi paylas.

## En hizli yol

Proje klasorunde su komutu calistir:

```bash
bash hazirla_paylasim.sh
```

Bu komut bir ust dizinde `JARVIS MAC CODEX SHAREABLE` klasoru olusturur. Zipleyip paylasman gereken klasor budur.

## Bu paket neden guvenli?

Asagidaki kisisel dosyalar paketten cikarilir ve yerlerine bos/sablon dosyalar konur:

- `config/api_keys.json`
- `memory/memory.json`
- `memory/phone_book.json`

Ayri olarak `.gitignore` dosyasi da eklendi. GitHub'a yuklersen bu dosyalar yanlislikla repoya girmez.

## Takipcilerin nasil kuracak?

Takipcilerine asagidaki adimlari gonderebilirsin:

### 1. Gerekenler

- macOS
- Python 3
- Homebrew

### 2. Kurulum

Terminal'de proje klasorune girip:

```bash
bash setup.sh
```

Kurulum bitince:

```bash
source venv/bin/activate
python main.py
```

### 3. API ayarlari

Ilk acilista uygulama kullanicidan kendi API anahtarlarini ister.

Gerekenler:

- Gemini API key: zorunlu
- YouTube API key: opsiyonel
- YouTube channel handle: opsiyonel

Isterlerse bunu arayuzden girebilirler, isterlerse `config/api_keys.json` dosyasini kendileri doldurabilirler.

## macOS izinleri

Bazi ozellikler icin kullanicinin kendi Mac'inde izin vermesi gerekir:

- Mikrofon: sesli komutlar icin
- Screen Recording: ekran analizi icin
- Accessibility: WhatsApp otomasyonu ve bazi medya kontrolleri icin
- Calendar: takvim okuma/ekleme/silme icin
- Reminders: animsaticilar icin

Takvim ve animsaticilar icin gerekirse Sistem Ayarlari > Privacy & Security altindan `JARVIS Calendar Helper` uygulamasina izin vermeleri gerekir.

## Apple Watch / saglik verisi kurulumu

Bu kisim opsiyoneldir. Saglik ozelligini kullanmak isteyen kisi kendi iPhone/Apple Watch verisini kendisi baglamalidir.

Anlatabilecegin kurulum:

1. iPhone'da bir saglik export uygulamasi kur.
2. JSON export'u iCloud Drive'a ayarla.
3. Hedef klasor `iCloud Drive > Auto Export > JARVIS` olsun.
4. Dosya adi `HealthAutoExport-YYYY-MM-DD.json` formatinda olursa JARVIS otomatik bulur.

Uygulama once su konumu kontrol eder:

- `~/Library/Mobile Documents/iCloud~com~ifunography~HealthExport/Documents/JARVIS`

Bulamazsa eski/alternatif iCloud konumlarini da dener.

## WhatsApp kisileri

Senin kendi kisi listen kesinlikle paylasilmamali.

Takipcilerin isterse:

- hic kisi dosyasi olmadan kullanabilir
- kendi `memory/phone_book.json` dosyasini olusturabilir
- kendi `.vcf` rehberini ice aktararak listeyi sonradan doldurabilir

## Ses efektleri

Projede ses efektleri opsiyoneldir. Bazi dosyalar yoksa uygulama bozulmaz; sadece ilgili efekt calmayabilir.

## Paylasmadan once son kontrol

- Gercek `api_keys.json` dosyasini acip tekrar kontrol etme, paylasilacak paket zaten temiz kopya uretir.
- Zipledigin klasorun adi `JARVIS MAC CODEX SHAREABLE` olsun.
- Orijinal calisma klasorunu degil, sadece uretilen temiz klasoru paylas.
